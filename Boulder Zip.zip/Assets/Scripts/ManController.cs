﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManController : MonoBehaviour {

    private float horizontal = 0.0f;
    private float vertcial = 0.0f;
    private float horizontal1 = 0.0f;
    private float vertcial1 = 0.0f;
    private bool right;
    private bool left;
    private bool down;
    private bool up;
    private Rigidbody2D rgbd;

    public GameObject fireUp, fireDown, fireLeft, fireRight, fireUpright, fireUpleft, fireDownright, fireDownleft;
    public float thrust;

	// Use this for initialization
	void Start () {
        rgbd = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
        horizontal = Input.GetAxis("Horizontal");
        vertcial = Input.GetAxis("Vertical");

        horizontal1 = Input.GetAxis("Horizontal1");
        vertcial1 = Input.GetAxis("Vertical1");

        BoolMovements();
        //IsSpinning();
        SetFire();
	}

    void FixedUpdate()
    {
        if (right)
            rgbd.AddForce(transform.right * thrust);
        else if (left)
            rgbd.AddForce(transform.right * -thrust);
        if (up)
            rgbd.AddForce(transform.up * thrust);
        else if (down)
            rgbd.AddForce(transform.up * -thrust);
    }

    void BoolMovements()
    {
        if (horizontal > .3f || horizontal1 > .3f)
            right = true;
        else
            right = false;

        if (horizontal < -.3f || horizontal1 < -.3f)
            left = true;
        else
            left = false;

        if (vertcial > .3f || vertcial1 > .3f)
            up = true;
        else
            up = false;

        if (vertcial < -.3f || vertcial1 < -.3f)
            down = true;
        else
            down = false;
    }

    void SetFire()
    {
        fireUp.GetComponent<SpriteRenderer>().enabled = false;
        fireDown.GetComponent<SpriteRenderer>().enabled = false;
        fireRight.GetComponent<SpriteRenderer>().enabled = false;
        fireLeft.GetComponent<SpriteRenderer>().enabled = false;
        fireUpright.GetComponent<SpriteRenderer>().enabled = false;
        fireUpleft.GetComponent<SpriteRenderer>().enabled = false;
        fireDownright.GetComponent<SpriteRenderer>().enabled = false;
        fireDownleft.GetComponent<SpriteRenderer>().enabled = false;

        if(!left && !right)
        {
            if (up)
                fireDown.GetComponent<SpriteRenderer>().enabled = true;
            else if (down)
                fireUp.GetComponent<SpriteRenderer>().enabled = true;
        } else if(!up && !down)
        {
            if (left)
                fireRight.GetComponent<SpriteRenderer>().enabled = true;
            else if (right)
                fireLeft.GetComponent<SpriteRenderer>().enabled = true;
        }
        else
        {
            if (up)
            {
                if (right)
                    fireDownleft.GetComponent<SpriteRenderer>().enabled = true;
                else if (left)
                    fireDownright.GetComponent<SpriteRenderer>().enabled = true;
            }else if (down)
            {
                if (right)
                    fireUpleft.GetComponent<SpriteRenderer>().enabled = true;
                else if (left)
                    fireUpright.GetComponent<SpriteRenderer>().enabled = true;
            }
        }

    }
}
