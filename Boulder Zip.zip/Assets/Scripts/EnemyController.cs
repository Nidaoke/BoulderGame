﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour {

    public GameObject bullet;
    public GameObject player;

	// Use this for initialization
	void Start () {
        StartCoroutine(Shoot(Random.Range(2.0f, 8.0f)));
    }

    IEnumerator Shoot(float time)
    {
        yield return new WaitForSeconds(time);

        GameObject bull = Instantiate(bullet, transform) as GameObject;
        bull.GetComponent<BulletScript>().Go(player);
        bull.transform.parent = null;

        StartCoroutine(Shoot(Random.Range(2.0f, 8.0f)));
    }
}
