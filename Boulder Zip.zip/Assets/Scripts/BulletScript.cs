﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletScript : MonoBehaviour {

    private Rigidbody2D rgbd;
    public float speed;
    //public GameObject playerf;

	// Use this for initialization
	void Start () {
        rgbd = GetComponent<Rigidbody2D>();
	}

    public void Go(GameObject player)
    {
        rgbd = GetComponent<Rigidbody2D>();

        Vector3 dir = player.transform.position - transform.position;
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

        rgbd.velocity = (transform.right * speed);

        /*Vector2 playerTransform = new Vector2(player.transform.position.x, player.transform.position.x);
        Vector2 outTransform = new Vector2(transform.position.x, transform.position.y);
        rgbd.velocity = (playerTransform - outTransform) * speed;*/
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
            Destroy(other.gameObject);
    }
}
