﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallControl : MonoBehaviour
{

    public Transform target;
    public Transform us;

    public float speed;
    public float spinSpeed;
    private Vector3 zAxis = new Vector3(0, 0, 1);

    private Rigidbody2D rgbd;

    private Vector2 targetVec;
    private Vector2 usVec;

    public float distance;

    // Use this for initialization
    void Start()
    {
        us = GetComponent<Transform>();
        rgbd = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {

        targetVec.x = target.position.x;
        targetVec.y = target.position.y;
        usVec.x = us.position.x;
        usVec.y = us.position.y;
        distance = Vector2.Distance(targetVec, usVec);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Enemy")
            Destroy(other.gameObject);
    }

    void FixedUpdate()
    {
        rgbd.AddForce((((targetVec - usVec) / 120) * (distance * distance * distance) * speed));
    }
}
