﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestRigidMove : MonoBehaviour {

    public Transform player;
    public float distance;
    public float speed;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 dir = player.position - transform.position;
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

        //sFollowTargetWithRotation(player, distance, speed);
	}

    void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().AddRelativeForce(Vector2.right * speed, ForceMode2D.Force);
    }

    void FollowTargetWithRotation(Transform target, float distanceToStop, float speed)
    {
        if(Vector3.Distance(transform.position, target.position) > distanceToStop)
        {
            transform.LookAt(target);
            GetComponent<Rigidbody2D>().AddRelativeForce(Vector3.forward * speed, ForceMode2D.Force);
        }
    }
}
